//创建时间：2016年8月15日 09:13:57
//创建人：李君
//说明：首页
!function(){
    var $page=$(j_m.currPage[0]);
    var me=j_m.currPage;
    me.hook(function(){
        Junb.addClass(me[0],'ready');
    });
}();