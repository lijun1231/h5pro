/**
 * Created by Administrator on 2016/9/13.
 */
!function(){
    var t=j_m.currPage;
    setTimeout(function(){
        console.log(t);
    });
}();


